package Entities;

public class Distritos {
    TSBHashtableDA distritos;
    public Distritos()
    {
        this.distritos = new TSBHashtableDA();
    }

    public TSBHashtableDA getDistritos()
    {
        return distritos;
    }

}
