package Entities;

public class Mesas {
    TSBHashtableDA mesas;
    public Mesas()
    {
        mesas = new TSBHashtableDA();
    }

    public TSBHashtableDA getMesas()
    {
        return mesas;
    }
}

