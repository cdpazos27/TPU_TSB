package Entities;

public class Secciones {
    TSBHashtableDA secciones;
    public Secciones()
    {
        this.secciones = new TSBHashtableDA();
    }

    public TSBHashtableDA getSecciones()
    {
        return secciones;
    }
}
