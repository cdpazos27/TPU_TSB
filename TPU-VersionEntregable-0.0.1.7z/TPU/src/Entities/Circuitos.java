package Entities;

public class Circuitos {
    TSBHashtableDA circuitos;
    public Circuitos()
    {
        circuitos = new TSBHashtableDA();
    }

    public TSBHashtableDA getCircuitos()
    {
        return circuitos;
    }
}
